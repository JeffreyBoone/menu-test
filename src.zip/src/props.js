export const title = {
    handboek: 'Handboek - LIOR',
    pve: "PvE Projecten",
    bijlagen: 'Bijlagen',
    BV: 'Bronverwijzingen',
    AR: 'Accounts en Rechten',
  };

export const desc = {
    handboek: 'Handboek Openbare Ruimte',
    pve: "Programma van Eisen",
    bijlagen: 'Raadplegen van Bijlagen',
    BV: 'Raadplegen van Bronverwijzingen',
    AR: 'Gebruikersadministratie',
  };
